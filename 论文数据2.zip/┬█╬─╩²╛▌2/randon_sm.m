clear all
rng(999)
%S1=4%1
sm_q=[];
tnum=8;
for ss1=1:tnum
I = double(ImageLoad1(ss1));
%I=double(imread('Lena.tiff'));
n=4;%%%n=8
num=256;%%%num=128
data=im2col(I,[n,n],'distinct');
col=ceil(randperm(size(data,2),num));
ini=data(:,col);
index=zeros(size(I,2)/n);
S1=randi(2,1,numel(index))-1;
for k=1:100
    for i=1:size(data,2)
        da=data(:,i)*ones(1,size(ini,2));
        [~,ind]=min(sum(abs((da-ini).^2)));
        index(i)=ind;
    end
end
[sm] = smooth(index);
imshow(uint8(index));
 %saveas (1,['D:\�о�\2020\��������2\paperdata\hong\',num2str(S1),'1.png'])
 saveas (1,['D:\�о�\2020\��������2\paperdata\random\',num2str(ss1),'.png'])
 sm_q=[sm_q;sm];
end
save randon_sm_q sm_q

clear all
rng(999)
%S1=4%1
sm_q=[];
tnum=8;
for ss1=1:tnum
I = double(ImageLoad1(ss1));
%I=double(imread('Lena.tiff'));
n=4;%%%n=8
num=256;%%%num=128
data=im2col(I,[n,n],'distinct');
col=ceil(randperm(size(data,2),num));
ini=data(:,col);
index=zeros(size(I,2)/n);
S1=randi(2,1,numel(index))-1;
for k=1:100
    for i=1:size(data,2)
        da=data(:,i)*ones(1,size(ini,2));
        [~,ind]=min(sum(abs((da-ini).^2)));
        index(i)=ind;
    end
    codebook=ini;
    for j=1:num
        ini(:,j)=mean(data(:,index==j),2);
    end
    if ini==codebook
        break;
    end
end

nub=sum(codebook(:,:));
[~,B]=sort(nub);
codebook=codebook(:,B);

for i=1:size(data,2)
    da=data(:,i)*ones(1,size(codebook,2));
    [~,ind]=min(sum(abs((da-codebook).^2)));
    index(i)=ind;
end

%%
%AIA
rng(99)
m=4;
X=zeros(numel(index)-1,3);
y=index';y=y(2:end)';
c=0;
for i=1:size(index,1)
    for j=1:size(index,2)
        if i==1 && j==1
            continue;
        else
            c=c+1;
            if i==1
                GL=index(i,j-1);
                GUL=GL;
                GU=GL;
            elseif j==1
                GU=index(i-1,j);
                GL=GU;
                GUL=GU;
            else
                GU=index(i-1,j);
                GL=index(i,j-1);
                GUL=index(i-1,j-1);
            end
            X(c,:)=[GL GU GUL];
        end
    end
end

rw=2;
rate=0.1;
rw1=randperm(999,rw);
for i=1:rw
    rng(rw1(i))
    x{i}=randperm(length(X),round(length(X)*rate));
    XX{i}=X(x{i},:);
    yy{i}=y(x{i});
    ww{i}=((XX{i}.'*XX{i})^(-1))*XX{i}.'*yy{i};
    p{i}=round(X*ww{i});
    dd{i}=y-p{i};
end

G=zeros(size(index));
c1=0;
js=1;
jn=0;
for i=1:size(index,1)
    for j=js:size(index,2)
        if jn>0
            jn=jn-1;
            continue;
        end
        js=1;
        if i==1 && j==1
            G(i,j)=0;
            continue;
        else
            c1=c1+1;
            if S1(c1+1)==0
                d=dd{1};
            else
                d=dd{2};
            end
            if i==1
                GL=index(i,j-1);
                GUL=GL;
                GU=GL;
            elseif j==1
                GU=index(i-1,j);
                GL=GU;
                GUL=GU;
            else
                GU=index(i-1,j);
                GL=index(i,j-1);
                GUL=index(i-1,j-1);
            end
            if index(i,j)==GL
                if c1+2<=numel(y)
                    if y(c1+1)==GL && y(c1+2)==GL
                        c1=c1+2;
                        G(i,j)=6;
                        if j==size(index,2);
                            G(i+1,1)=6;G(i+1,2)=6;
                            js=3;
                        elseif j==size(index,2)-1;
                            G(i+1,1)=6;G(i,j+1)=6;
                            js=2;
                            break;
                        else
                            G(i,j+1)=6;G(i,j+2)=6;
                            js=1;
                            jn=2;
                        end
                    else
                        G(i,j)=1;
                    end
                else
                    G(i,j)=1;
                end
            elseif index(i,j)==GU
                G(i,j)=2;
            elseif index(i,j)~=GL && index(i,j)~=GU
                if d(c1)>=0 && d(c1)<=2^m-1
                    G(i,j)=3;
                elseif d(c1)<0 && d(c1)>=-(2^m-1)
                    G(i,j)=4;
                elseif abs(d(c1))>2^m-1
                    if c1+2<=numel(y)
                        if abs(d(c1+1))>2^m-1 && abs(d(c1+2))>2^m-1
                            c1=c1+2;
                            G(i,j)=7;
                            if j==size(index,2);
                                G(i+1,1)=7;G(i+1,2)=7;
                                js=3;
                            elseif j==size(index,2)-1;
                                G(i+1,1)=7;G(i,j+1)=7;
                                js=2;
                                break;
                            else
                                G(i,j+1)=7;G(i,j+2)=7;
                                js=1;
                                jn=2;
                            end
                        else
                            G(i,j)=5;
                        end
                    else
                        G(i,j)=5;
                    end
                end
            end
        end
    end
end

%%
M=4%log2(256);

r={[dec2bin(0,2)] [dec2bin(1,2)] [dec2bin(4)] [dec2bin(5)] [dec2bin(6)] [dec2bin(14)] [dec2bin(15)]};
for i=1:7
    T(i)=length(find(G==i));
end
[~,ord]=sort(T,'descend');
[~,or]=sort(ord);
r=r(or);
g=G';g=g(2:end)';
CS=[dec2bin(S1(1)) dec2bin(index(1),M)];
c1=1;
jn=0;
for i=1:numel(g)
    if jn>0
        jn=jn-1;
        continue;
    end
    c1=c1+1;
    if S1(c1)==0
        d=dd{1};
    else
        d=dd{2};
    end
    if g(i)==1
        CS=[CS dec2bin(S1(c1)) r{1}];
    elseif g(i)==2
        CS=[CS dec2bin(S1(c1)) r{2}];
    elseif g(i)==3
        CS=[CS dec2bin(S1(c1)) r{3} dec2bin(d(i),m)];
    elseif g(i)==4
        CS=[CS dec2bin(S1(c1)) r{4} dec2bin(-d(i),m)];
    elseif g(i)==5
        CS=[CS dec2bin(S1(c1)) r{5} dec2bin(y(i),M)];
    elseif g(i)==6
        CS=[CS dec2bin(S1(c1)) r{6} dec2bin(S1(c1+1)) dec2bin(S1(c1+2))];
        c1=c1+2;
        jn=2;
    elseif g(i)==7
        CS=[CS dec2bin(S1(c1)) r{7} dec2bin(S1(c1+1)) dec2bin(S1(c1+2)) dec2bin(y(i),M) dec2bin(y(i+1),M) dec2bin(y(i+2),M)];
        c1=c1+2;
        jn=2;
    end
end

CSS=CS;

%%
%decode

ind=zeros(size(index));
c1=0;
jn=0;
for i=1:size(index,1)
    for j=1:size(index,2)
        if jn>0
            jn=jn-1;
            if inx==6
                ind(i,j)=bb;
            else
                ind(i,j)=bin2dec(CS(1:M));
                CS=CS(M+1:end);
            end
            continue;
        end
        c1=c1+1;
        S(c1)=CS(1);
        if S(c1)-'0'==0
            w=ww{1};
        else
            w=ww{2};
        end
        if i==1 && j==1
            ind(i,j)=bin2dec(CS(2:1+M));
            CS=CS(2+M:end);
        else
            if i==1
                GL=ind(i,j-1);
                GUL=GL;
                GU=GL;
            elseif j==1
                GU=ind(i-1,j);
                GL=GU;
                GUL=GU;
            else
                GU=ind(i-1,j);
                GL=ind(i,j-1);
                GUL=ind(i-1,j-1);
            end
            buf={[CS(2:3)] [CS(2:4)] [CS(2:5)]};
            for t=1:3
                [~,inx]=ismember(buf{t},r);
                if inx==1
                    ind(i,j)=GL;
                    CS=CS(2+numel(buf{t}):end);
                    break;
                elseif inx==2
                    ind(i,j)=GU;
                    CS=CS(2+numel(buf{t}):end);
                    break;
                elseif inx==3 || inx==4
                    dd2=bin2dec(CS(2+numel(buf{t}):1+numel(buf{t})+m));
                    pp=round(w(1)*GL+w(2)*GU+w(3)*GUL);
                    if inx==3
                        ind(i,j)=pp+dd2;
                    else
                        ind(i,j)=pp-dd2;
                    end
                    CS=CS(2+numel(buf{t})+m:end);
                    break;
                elseif inx==5
                    ind(i,j)=bin2dec(CS(2+numel(buf{t}):1+numel(buf{t})+M));
                    CS=CS(2+numel(buf{t})+M:end);
                    break;
                elseif inx==6
                    S(c1+1:c1+2)=CS(2+numel(buf{t}):1+numel(buf{t})+2);
                    ind(i,j)=GL;
                    bb=ind(i,j);
                    jn=2;c1=c1+2;
                    CS=CS(2+numel(buf{t})+2:end);
                    break;
                elseif inx==7
                    S(c1+1:c1+2)=CS(2+numel(buf{t}):1+numel(buf{t})+2);
                    ind(i,j)=bin2dec(CS(2+numel(buf{t})+2:1+numel(buf{t})+2+M));
                    CS=CS(2+numel(buf{t})+2+M:end);
                    c1=c1+2;
                    jn=2;
                    break;
                end
            end
        end
    end
end

s1=sum(S1-(S-'0'))
s2=sum(sum(index-ind))
le=length(CSS)
[sm] = smooth(index);
imshow(uint8(index));
 %saveas (1,['D:\�о�\2020\��������2\paperdata\hong\',num2str(S1),'1.png'])
 saveas (1,['D:\�о�\2020\��������2\paperdata\yuyang\',num2str(ss1),'.png'])
 sm_q=[sm_q;sm];
end
save yuyang_sm_q sm_q

%
% 
% Tabu search algorithm for rearranging index talbe and codebook
% 
% % % % % % % % % % % % % % % % % % 
% 
% Modified by Zhijie Wu
% Sep,2019 - Jan,2020
%
% % % % % % % % % % % % % % % % % % 
% Copyright (c) 2020, Zhijie Wu
% All rights reserved.
%
%%  �������벾
load('CB256.mat');
%codebook = codebook';
n = 4;                                    % 4 * 4��С��
[CB2,ind]=sort(sum(CB256));               
codebook=CB256(:,ind);
N = 256;
[index_table]=VQ_bianma(codebook,I,n,N);                  %���ú��� VQ_bianma ���������� G
%%  ���㹲�־���
index_table_size = size(index_table);
C = zeros(N,N);
for i = 1:index_table_size(1,1)
    series = index_table(i,:);
    series_size = size(series);
    for j = 1:(series_size(1,2)-1)
        C(series(1,j),series(1,j+1)) = C(series(1,j),series(1,j+1)) + 1;
        C(series(1,j+1),series(1,j)) = C(series(1,j+1),series(1,j)) + 1;
    end
end
for i = 1:index_table_size(1,2)
    series = index_table(:,i);
    series_size = size(series);
    for j = 1:(series_size(1,1)-1)
        C(series(j,1),series(j+1,1)) = C(series(j,1),series(j+1,1)) + 1;
        C(series(j+1,1),series(j,1)) = C(series(j+1,1),series(j,1)) + 1;
    end
end
for i = 1:N
    C(i,i) = 0;
end
%% ���������㷨������
temp = unique(index_table);
temp = temp';
L = size(temp,2);%����Ĺ�ģ
s0 = load('listR.csv');%��ʼ�⣬����ǰ�ķ����������
% s0 = temp(randperm(L));
tabulist = zeros(N);%���ɱ�
tabulength = 20;%���ɳ���
candidateNum = 1000;%��ѡ�����
candidates = zeros(candidateNum,L);%��ѡ�⼯��
bsf = s0;
%bestfitness = fit(C,s0,L);
bestfitness=newfit(G,s0);
tic
p = 1;
%stop = 80 * L;
stop = 250;%ֹͣ��������
while p < stop
    if candidateNum > L * (L - 1) / 2
       disp('��ѡ�����������n*(n-1)/2') ;
       break;
    end
    %along(p) = fit(C,s0,L);
    along(p)=newfit(G,s0);
    i = 1;
    A = zeros(candidateNum,2);
    while i <= candidateNum % 
        M = ceil(L * rand(1,2));
        if M(1) ~= M(2)
           A(i,1) = max(M(1),M(2));
           A(i,2) = min(M(1),M(2));
           if i == 1
               isa = 0;
           else
               for j = 1:i - 1
                   if A(i,1) == A(j,1) && A(i,2) == A(j,2)
                       isa = 1;
                       break;
                   else
                       isa = 0;
                   end
               end
           end
           if ~isa
              i = i+1;
           else
           end
        else
        end
    end
    bestCandidateNum = 200;%�������ٸ���ú�ѡ��
    bestCandidate = zeros(bestCandidateNum,4);%1:��ţ�2����Ӧ�ȣ�3��4����������
    F = zeros(1,candidateNum);
    for i = 1:candidateNum
        candidates(i,:) = s0;
        candidates(i,[A(i,2),A(i,1)]) = s0([A(i,1),A(i,2)]);%����������һ����ѡ��
        %F(i) = fit(C,candidates(i,:),L);
        F(i)=newfit(G,candidates(i,:));
        if i <= bestCandidateNum
            bestCandidate(i,2) = F(i);
            bestCandidate(i,1) = i;
            bestCandidate(i,3) = s0(A(i,1));
            bestCandidate(i,4) = s0(A(i,2));
        else
            for j = 1:bestCandidateNum
                if F(i) > bestCandidate(j,2)%�޸Ĺ�����
                   bestCandidate(j,2) = F(i);
                   bestCandidate(j,1) = i;
                   bestCandidate(j,3) = s0(A(i,1));
                   bestCandidate(j,4) = s0(A(i,2));
                   break;
                end
            end
        end
    end
    %��bestCandidate
    [JL,index] = sort(bestCandidate(:,2));
    sbest = bestCandidate(index,:);
    bestCandidate = sbest;
    if bestCandidate(end,2) > bestfitness%�޸Ĺ�> ->  <
        bestfitness = bestCandidate(end,2);
        s0 = candidates(bestCandidate(end,1),:);
        bsf = s0;
        for m = 1:L
            for n = 1:L
                if tabulist(m,n) ~= 0
                    tabulist(m,n) = tabulist(m,n) - 1;
                end
            end
        end
        tabulist(bestCandidate(end,3),bestCandidate(end,4)) = tabulength;
        tabulist(bestCandidate(end,4),bestCandidate(end,3)) = tabulength;%
    else
        for i = bestCandidateNum:-1:1
            if tabulist(bestCandidate(i,3),bestCandidate(i,4)) == 0
                s0 = candidates(bestCandidate(i,1),:);
                for m = 1:L
                    for n = 1:L
                       if tabulist(m,n) ~= 0
                           tabulist(m,n) = tabulist(m,n) - 1;
                       end
                    end
                end
                tabulist(bestCandidate(i,3),bestCandidate(i,4)) = tabulength;
                tabulist(bestCandidate(i,4),bestCandidate(i,3)) = tabulength;
                break;
            else
                %if fit(C,candidates(bestCandidate(i,1),:),L) > bestfitness*0.9
                if newfit(G,candidates(bestCandidate(i,1),:)) > bestfitness*0.9
                    s0 = candidates(bestCandidate(i,1),:);
                   %
                   for m = 1:L
                        for n = 1:L
                            if tabulist(m,n) ~= 0
                                tabulist(m,n) = tabulist(m,n) - 1;
                            end
                        end
                   end
                   tabulist(bestCandidate(i,3),bestCandidate(i,4)) = tabulength;
                   tabulist(bestCandidate(i,4),bestCandidate(i,3)) = tabulength;
                   [bestCandidate(i,3),bestCandidate(i,4)]
                   %
                   break;
                end
            end
        end
    end
    p = p + 1
    arrbestfitness(p) = 1/bestfitness; 
   % figure(1);
    %plot(2:p,arrbestfitness(1,2:end));
%     figure(2);
%     plot(1:p-1,along);
end
toc;
% csvwrite('50000House2.csv',bsf);%Ϊ�˷�����ԣ����԰����򱣴�����














function [It]=VQ_bianma(c,I,n,N)
data=im2col(I,[n n],'distinct');
It=zeros(size(I,1)/n,size(I,2)/n);
for i=1:size(data,2)
    [~,p]=min(sum((data(:,i)*ones(1,N)-c).^2));
    It(i)=p;
end
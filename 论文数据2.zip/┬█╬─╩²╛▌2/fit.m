%
% 
% Fitness function
% 
% % % % % % % % % % % % % % % % % % 
% 
% Modified by Zhijie Wu
% Sep,2019 - Jan,2020
%
% % % % % % % % % % % % % % % % % % 
% Copyright (c) 2020, Zhijie Wu
% All rights reserved.
%
function fitness = fit(C,individual,L)%C�ǹ��־���individual�Ǹ���
    fitness = 0;
    for i = 1:L
       for j = 1:L
           %if i + 1 == j || i - 1 == j
              fitness = fitness + C(individual(i) , individual(j)) * abs(i - j);
           %else
           %    fitness = fitness + 0;
           %end
       end
    end
    fitness = 1 / fitness;
end
function v=D2B(num,digits)
v=mod(floor(num./(2.^(digits-1:-1:0))),2);

% function v=D2B(num,digits)  
% v=zeros(size(num,1),digits);
% for i=1:size(num,1)
% v(i,:)=mod(floor(num(i)./(2.^(digits-1:-1:0))),2);
% end
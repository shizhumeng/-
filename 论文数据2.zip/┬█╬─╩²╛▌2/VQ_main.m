%Img='Lena_Gray.tiff';
%I=double(imread('Lena_Gray.tiff'));
clc
clear
sm_q=[];
tnum=8;
for S1=1:tnum
I = double(ImageLoad1(S1)); 
%I=I(1:16,1:16);
%I=I';
%I=double(imread(['C:\Users\Shuozhen\Documents\MATLAB\bows2-1g.tar\',num2str(408),'.pgm']));
IL=length(I);
sbit=0;                                   %ÿ������ֵGǶ���bit��
m=5;                                      %��4��bitȥ��¼
n=4;                                      %�г�4*4��С��
N=256;                                    %һ���� N ��������
p=0.5;
fprintf('m=%d,N=%d,sbit=%d\n',m,N,sbit);
%%  G ����� 'GN' ����������¼
GN=log2(N);
%%  �������벾
load('CB256.mat')
[CB2,ind1]=sort(sum(CB256));               %�ѱ��벾 CB256 ��С������������
C0=CB256(:,ind1);
[G]=VQ_bianma(C0,I,n,N);     
G1=G;
%���ú��� VQ_bianma ���������� G
%% reindex������
[II2]=VQ_jiema(I,C0,G1,n);
CBSize=N;
G2=padarray(G,[1,1],CBSize+1,'both');
C=zeros(CBSize+1);                  % reindex�����ڴ�����
for i=2:size(G2,1)-1
    for j=2:size(G2,2)-1
        C(G2(i,j),G2(i-1,j))=C(G2(i,j),G2(i-1,j))+1;
        C(G2(i,j),G2(i+1,j))=C(G2(i,j),G2(i+1,j))+1;
        C(G2(i,j),G2(i,j-1))=C(G2(i,j),G2(i,j-1))+1;
        C(G2(i,j),G2(i,j+1))=C(G2(i,j),G2(i,j+1))+1;
    end
end
C(:,end)=[];
C(end,:)=[];
%%      
pos=0;r=0;c=0;
for i=1:size(C,1)
    for j=1:size(C,2)
        if i~=j
            if C(i,j)>=pos
                pos=C(i,j);
                r=i;c=j;
            end
        end
    end
end
PN=[r,c];
Gp=unique(G);
pr=find(Gp==r);
Gp(pr)=[];
pc=find(Gp==c);
Gp(pc)=[];
%% �� Ui
ij=1;
listR=PN;
while ij<=numel(Gp)
    N=size(listR,2);
    Ui=0;pos=0;
    for i=1:numel(Gp)
        total=0;
        for j=1:N
            cnt=C(Gp(i),listR(j));
            cnt=cnt.^(p);
            total=total+cnt;
        end
        if total>=pos
            pos=total;
            Ui=Gp(i);
        end
    end
    %
    pr=find(Gp==Ui);
    Gp(pr)=[];
    
    %
    totalL=0;
    for j=1:floor(N/2)
        cnt2=C(Ui,listR(j));
        totalL=totalL+cnt2;
    end
    %
    totalR=0;
    for j=(floor(N/2)+1):N
        cntR=C(Ui,listR(j));
        totalR=totalR+cntR;
    end
    if totalL>totalR
        listR=[Ui,listR];    %�������
    else
        listR=[listR,Ui];    %�����ұ�
    end
end
%% �ı�����ֵG
for i=1:numel(G)
    p=find(listR==G(i));
    G(i)=p;
end
%%
G2=G;
G=G-1;                                    %0~255 ��8bit ���� ��matlab�б�ʾ����1~256
%%  ���ɡ�w��---�� Least Square Estimator(��С���˷���
Y=G(2:size(G,1),2:size(G,2));
GL1=(G(2:size(G,1),1:size(G,2)-1));
GU1=(G(1:size(G,1)-1,2:size(G,2)));
GUL1=(G(1:size(G,1)-1,1:size(G,2)-1));
X=[GL1(:) GU1(:) GUL1(:)];
w=((X'*X)^(-1)*(X'*Y(:)));
%% ��LSE��Ԥ�� ����ֵ�����ֵ
d=zeros(size(G,1),size(G,2));
Gp=zeros(size(G,1),size(G,2));
for i=1:size(G,1)
    for j=1:size(G,2)
        if i==1 && j~=1
            GL=G(i,j-1);GU=GL;GUL=GL;
        elseif i~=1 && j==1
            GU=G(i-1,j);GL=GU;GUL=GU;
        elseif i>=2 && j>=2
            GL=G(i,j-1);GU=G(i-1,j);GUL=G(i-1,j-1);
        end
        if i==1 && j==1
            continue;
        else
           Gp(i,j)=(sum((w'.*[GL GU GUL])));        %Least Square Estimator(��С���˷����Ĺ�ʽ
        end
         d(i,j)=round(G(i,j)-Gp(i,j));
    end
end
%histogram(d(:),-50,50) 
d1=zeros(size(G,1),2);
%d1(:,end-1:end)=nan;
dp=[d,d1];
%%  AIA����
g=zeros(size(G,1),2);
Gg=[G,g];
Gg(:,end-1:end)=-1;
k=zeros(1,7);                %��7������
Case=zeros(size(G,1),size(G,2));
for i=1:size(G,1)
    j=1;
    while j<=size(G,2)
        if i==1 && j~=1
            GL=G(i,j-1);GU=GL;GUL=GL;
        elseif i~=1 && j==1
            GU=G(i-1,j);GL=GU;GUL=GU;
        elseif i>=2 && j>=2
            GL=G(i,j-1);GU=G(i-1,j);GUL=G(i-1,j-1);
        end
        %
        if i==1 && j==1
            j=j+1;
            continue;
        elseif (Gg(i,j)==Gg(i,j+1) && Gg(i,j+1)==Gg(i,j+2)) && Gg(i,j+2)==GL
            k(6)=k(6)+3;
            Case(i,j)=6;
            Case(i,j+1)=6;
            Case(i,j+2)=6;
            j=j+3;
        elseif Gg(i,j)==GL && (Gg(i,j+1)~=Gg(i,j) || Gg(i,j+2)~=Gg(i,j))
            k(1)=k(1)+1;
            Case(i,j)=1;
            j=j+1;
        elseif Gg(i,j)==GU 
            k(2)=k(2)+1;
            Case(i,j)=2;
            j=j+1;
        elseif dp(i,j)>=0 && dp(i,j)<=2^m-1
            k(3)=k(3)+1;
            Case(i,j)=3;
            j=j+1;
        elseif dp(i,j)<0 && dp(i,j)>=-(2^m-1)
            k(4)=k(4)+1;  
            Case(i,j)=4;
            j=j+1;
        elseif abs(dp(i,j))>2^m-1 && (abs(dp(i,j+1))<=2^m-1 || abs(dp(i,j+2))<=2^m-1)
            k(5)=k(5)+1;
            Case(i,j)=5;
            j=j+1;
        elseif abs(dp(i,j))>2^m-1 && abs(dp(i,j+1))>2^m-1 && abs(dp(i,j+2))>2^m-1
            k(7)=k(7)+3;
            Case(i,j)=7;
            Case(i,j+1)=7;
            Case(i,j+2)=7;
            j=j+3;
        end
    end
end
k(6)=k(6)/3;
k(7)=k(7)/3;
%Li3=sum(k)
r={[0 0] [0 1] [1 0 0] [1 0 1] [1 1 0] [1 1 1 0] [1 1 1 1]};  %��ԭʼ��r
[val,ind]=sort(k,'descend');
rp(ind)=r;                                                     %����Ҫ�������������r
L1=length(rp{1});L2=length(rp{2});L3=length(rp{3});
L4=length(rp{4});L5=length(rp{5});L6=length(rp{6});L7=length(rp{7});
Lindicator =sum(sum(k.*[L1 L2 L3 L4 L5 L6 L7]));
Length_Prediction=(k(3)+k(4))*m+k(5)*GN+k(7)*3*GN;
%fprintf('Lindicator=%d,Length_Prediction=%d\n',Lindicator,Length_Prediction);
%%  ����
rng(999)
S=randi([0 1],[1,sbit*numel(G)]);
Gcs=[];
k=1;
cnt=1;
% �����һ��Ԫ��
Gcs(k:k+sbit-1)=S(cnt:cnt+sbit-1);
k=k+sbit;
cnt=cnt+sbit;
Gcs(k:k+GN-1)=D2B(G(1,1),GN);
k=k+GN;
LP=0;
%
for i=1:size(G,1)
    j=1;
    while j<=size(G,2)
        if i==1 && j==1
            j=j+1;
           continue 
        else
            Gcs(k:k+sbit-1)=S(cnt:cnt+sbit-1);
            k=k+sbit;
            cnt=cnt+sbit;
            if Case(i,j)==1
                Gcs(k:k+L1-1)=rp{1};
                k=k+L1;
                j=j+1;
            elseif Case(i,j)==2
                Gcs(k:k+L2-1)=rp{2};
                k=k+L2;
                j=j+1;
            elseif Case(i,j)==3
                Gcs(k:k+L3-1)=rp{3};
                k=k+L3;
                Gcs(k:k+m-1)=D2B(d(i,j),m);
                k=k+m;
                LP=LP+m;
                j=j+1;
            elseif Case(i,j)==4
                Gcs(k:k+L4-1)=rp{4};
                k=k+L4;
                Gcs(k:k+m-1)=D2B(abs(d(i,j)),m);
                k=k+m;
                LP=LP+m;
                j=j+1;
            elseif Case(i,j)==5
                Gcs(k:k+L5-1)=rp{5};
                k=k+L5;
                Gcs(k:k+GN-1)=D2B(G(i,j),GN);
                k=k+GN;
                 LP=LP+GN;
                j=j+1;
            elseif Case(i,j)==6
                Gcs(k:k+L6-1)=rp{6};
                k=k+L6;
                Gcs(k:(k+2*sbit-1))=S(cnt:(cnt+2*sbit-1));
                k=k+2*sbit;
                cnt=cnt+2*sbit;
                j=j+3;
             elseif Case(i,j)==7
                Gcs(k:k+L7-1)=rp{7};
                k=k+L7;
                Gcs(k:(k+2*sbit-1))=S(cnt:(cnt+2*sbit-1));
                k=k+2*sbit;
                cnt=cnt+2*sbit;
                Gcs(k:k+GN-1)=D2B(G(i,j),GN);
                k=k+GN;
                LP=LP+GN;
                Gcs(k:k+GN-1)=D2B(G(i,j+1),GN);
                k=k+GN;
                LP=LP+GN;
                Gcs(k:k+GN-1)=D2B(G(i,j+2),GN);
                k=k+GN;
                LP=LP+GN;
                j=j+3;
            end
        end
    end
end
pure_bitrate=length(Gcs)/(512*512);
%fprintf('LP=%d,pure_bitrate=%1.3f',LP,pure_bitrate);
%length(Gcs)/(512*512)

%%  ����
%w1=[0.4200;0.8031;-0.2313];
%w1=[0.333;0.333;0.333];
RG=zeros(size(G));                         %��ԭ���������
RS=[];                                     %��ԭ��Ļ�����Ϣ
k1=1;
cnt1=1;
%�Ƚ����һ��Ԫ��
RS(cnt1:cnt1+sbit-1)=Gcs(k1:k1+sbit-1);
k1=k1+sbit;
cnt1=cnt1+sbit;
RG(1,1)=B2D(Gcs(k1:k1+GN-1));
k1=k1+GN;
%
RGp=zeros(size(G,1),size(G,2));               
RCase=zeros(size(G,1),size(G,2));           %��ԭ��������
for i=1:size(G,1)
    j=1;
    while j<=size(G,2)
        if (i==1 && j==1)
            j=j+1;
            continue;
        end
        if i==1 && j~=1
            GL=RG(i,j-1);GU=GL;GUL=GL;
        elseif i~=1 && j==1
            GU=RG(i-1,j);GL=GU;GUL=GU;
        elseif i>=2 && j>=2
            GL=RG(i,j-1);GU=RG(i-1,j);GUL=RG(i-1,j-1);
        end
        %
        RS(cnt1:cnt1+sbit-1)=Gcs(k1:k1+sbit-1);
        k1=k1+sbit;
        cnt1=cnt1+sbit;
        RGp(i,j)=(sum((w'.*[GL GU GUL])));
        if all(Gcs(k1:k1+L1-1)==rp{1})
            k1=k1+L1;
            RG(i,j)=round(GL);
            RCase(i,j)=1;
            j=j+1;
        elseif all(Gcs(k1:k1+L2-1)==rp{2})
            k1=k1+L2;
            RG(i,j)=round(GU);
            RCase(i,j)=2;
            j=j+1;
        elseif all(Gcs(k1:k1+L3-1)==rp{3})
            k1=k1+L3;
            RG(i,j)=round(RGp(i,j)+B2D(Gcs(k1:k1+m-1)));
            k1=k1+m;
            RCase(i,j)=3;
            j=j+1;
        elseif all(Gcs(k1:k1+L4-1)==rp{4})
            k1=k1+L4;
            RG(i,j)=round(RGp(i,j)-B2D(Gcs(k1:k1+m-1)));
            k1=k1+m;
            RCase(i,j)=4;
            j=j+1;
        elseif all(Gcs(k1:k1+L5-1)==rp{5})
            k1=k1+L5;
            RG(i,j)=round(B2D(Gcs(k1:k1+GN-1)));
            k1=k1+GN;
            RCase(i,j)=5;
            j=j+1;
        elseif all(Gcs(k1:k1+L6-1)==rp{6})
            k1=k1+L6;
            RS(cnt1:(cnt1+2*sbit-1))=Gcs(k1:(k1+2*sbit-1));
            cnt1=cnt1+2*sbit;
            k1=k1+2*sbit;
            RG(i,j)=round(GL);
            RG(i,j+1)=round(GL);
            RG(i,j+2)=round(GL);
            RCase(i,j)=6;
            RCase(i,j+1)=6;
            RCase(i,j+2)=6;
            j=j+3;
        elseif all(Gcs(k1:k1+L7-1)==rp{7})
            k1=k1+L7;
            RS(cnt1:(cnt1+2*sbit-1))=Gcs(k1:(k1+2*sbit-1));
            cnt1=cnt1+2*sbit;
            k1=k1+2*sbit;
            RG(i,j)=round(B2D(Gcs(k1:k1+GN-1)));
            k1=k1+GN;
            RG(i,j+1)=round(B2D(Gcs(k1:k1+GN-1)));
            k1=k1+GN;
            RG(i,j+2)=round(B2D(Gcs(k1:k1+GN-1)));
            k1=k1+GN;
            RCase(i,j)=7;
            RCase(i,j+1)=7;
            RCase(i,j+2)=7;
            j=j+3;
        end
    end
end
%% ���黹ԭ�Ƿ���ȷ
su1=sum(sum(abs(RCase-Case)));
%sum(sum(abs(RS-S)))
su3=sum(sum(abs(RG-G)));
% length(Gcs)/(512*512)
fprintf('su1=%d,su3=%d\n',su1,su3);
%
 %G=G+1;
 %RG=RG+1;
 %[II]=VQ_jiema(I,C0,RG,n);
 
 
 imshow(uint8(G))
 saveas (1,['D:\�о�\2020\��������2\paperdata\hong\',num2str(S1),'.png'])
 [sm] = smooth(RG)
 sm_q=[sm_q;sm];
end
save hong_sm_q sm_q
%%
% k7=0;k6=0;k5=0;k4=0;
% k3=0;k2=0;k1=0;
% for i=1:numel(Case)
%     if Case(i)==7
%         k7=k7+1;
%     elseif Case(i)==6
%         k6=k6+1;
%     elseif Case(i)==5
%         k5=k5+1;
%     elseif Case(i)==4
%         k4=k4+1;
%     elseif Case(i)==3
%         k3=k3+1;
%     elseif Case(i)==2
%         k2=k2+1;
%     elseif Case(i)==1
%         k1=k1+1;
%     end
% end
%%
% x=[128 256 512 1024];
% y=[0.2691 0.3194 0.3926 0.4682];
% hold on
% plot(x,y,'-ro')
%length(Gcs)
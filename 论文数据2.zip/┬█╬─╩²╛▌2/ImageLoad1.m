function [cover] = ImageLoad1(S)
name={'Lena','Baboon','Jet','Stream','Tiffany','Boat','Peppers','House','elaine','sail'};
if S==9 || S==10
    cover=imread([name{S},'.bmp'],'bmp');
else 
    cover=imread([name{S},'_Gray.tiff'],'TIFF');
end
end







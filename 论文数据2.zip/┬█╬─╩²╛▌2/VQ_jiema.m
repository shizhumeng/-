function [II]=VQ_jiema(I,c,It,n)
data=im2col(I,[n n],'distinct');
%dim=size(data,1);
Ii=zeros(size(data));
for i=1:numel(It)
    Ii(:,i)=c(:,(It(i)));
end
II=col2im(Ii,[n n],[length(I),length(I)],'distinc');
%
% 
% Based on tabu search algorithm and adaptive run-through coding,losslessly hidden information in VQ indices
% 
% % % % % % % % % % % % % % % % % % 
% 
% Modified by Zhijie Wu
% Sep,2019 - Jan,2020
%
% % % % % % % % % % % % % % % % % % 
% Copyright (c) 2020, Zhijie Wu
% All rights reserved.
%
%% Design:
% 1.Rearrange codebook and index_table
% 2.Predict the index value
% 3.Coding
% 4.Decoding
%% 
clear
clc
I=double(imread('Lena_Gray.tiff'));
IL=length(I);
sbit=1;                                   %ÿ������ֵGǶ���bit��
n=4;                                      %�г�4*4��С��
p=0.5;
[CB2,ind]=sort(sum(CB256));               %�ѱ��벾 CB256 ��С������������
C=CB256(:,ind);
N=size(C,2);                                    %һ���� N ��������
[G]=VQ_bianma(C,I,n,N);                  %���ú��� VQ_bianma ���������� G
    
tsp_tabusearch;
listR = bsf;
csvwrite('listR.csv',listR);
%% �ı�����ֵG
for i=1:numel(G)
    p=find(listR==G(i));
    G(i)=p;
end
%%
G=G-1;                                    %0~255 ��8bit ���� ��matlab�б�ʾ����1~256
imagesc(G)
%%  ���ɡ�w��---�� Least Square Estimator(��С���˷���������ʦ������������Ԥ�⣬�������ĸ����أ�����Ԥ�������С
Y=G(2:size(G,1),2:size(G,2)-1);
GL1=(G(2:size(G,1),1:size(G,2)-2));
GU1=(G(1:size(G,1)-1,2:size(G,2)-1));
GUL1=(G(1:size(G,1)-1,1:size(G,2)-2));
GUR1 = G(1:size(G,1)-1,3:size(G,2));
X=[ GL1(:) GU1(:) GUL1(:) GUR1(:)];
%w=inv(X'*X)*X'*Y(:);
w=((X'*X)^(-1)*(X'*Y(:)));
%% ��LSE��Ԥ�� ����ֵ�����ֵ
d=zeros(size(G,1),size(G,2));
Gp=zeros(size(G,1),size(G,2));
for i=1:size(G,1)
    for j=1:size(G,2)
        if i ==6 && j ==128
               0; 
        end
        if i==1 && j~=1
            GL=G(i,j-1);GU=GL;GUL=GL;GUR = GL;
        elseif i~=1 && (j==1||j == size(G,2))
            GU=G(i-1,j);GL=GU;GUL=GU;GUR = GU;
        elseif i>=2 && j>=2
            GL=G(i,j-1);GU=G(i-1,j);GUL=G(i-1,j-1);GUR = G(i-1,j+1);
        end
        if i==1 && j==1
            continue;
        else
           Gp(i,j)=(sum((w'.*[GL GU GUL GUR])));        %Least Square Estimator(��С���˷����Ĺ�ʽ
        end
         d(i,j)=round(G(i,j)-Gp(i,j));
    end
end
%histogram(d(:),-50,50)
sum(sum(abs(d)))
d1=zeros(size(G,1),2);
%d1(:,end-1:end)=nan;
dp=[d,d1];
pbr = [];
br = [];
%% ���ݲ�ͬ��Ԥ������Ƕ��λ����ѭ��Ƕ�롣ʵ������pbr-�������������ʣ�br-���������ʣ�min_br-�������������
for m = 1:7
    %%  AIA����
%     m=4;
    g=zeros(size(G,1),2);
    Gg=[G,g];
    Gg(:,end-1:end)=-1;
    k=zeros(1,7);                %��7������
    Case=zeros(size(G,1),size(G,2));
    for i=1:size(G,1)
        j=1;
        while j<=size(G,2)
            if i==1 && j~=1
                GL=G(i,j-1);GU=GL;GUL=GL;
            elseif i~=1 && (j==1||j==size(G,2))
                GU=G(i-1,j);GL=GU;GUL=GU;
            elseif i>=2 && j>=2
                GL=G(i,j-1);GU=G(i-1,j);GUL=G(i-1,j-1);
            end
            %
            if i==1 && j==1
                j=j+1;
                continue;
            elseif (Gg(i,j)==Gg(i,j+1) && Gg(i,j+1)==Gg(i,j+2)) && Gg(i,j+2)==GL
                k(6)=k(6)+1;
                flag = 1;
                jj = 2;
                while flag == 1 %���������������ͬ�ϣ��ٶԺ����������������������γ̱��룬����Ϊͬһ��case,ʵ������Ӧ�γ̱���
                    if Gg(i,j+jj+1) == GL
                       jj = jj + 1; 
                    else
                        flag = 0;
                    end
                end
                for temp = 0 : jj
                    Case(i,j + temp) = 6;
                end
                j=j+jj+1;
            elseif Gg(i,j)==GL && (Gg(i,j+1)~=Gg(i,j) || Gg(i,j+2)~=Gg(i,j))
                k(1)=k(1)+1;
                Case(i,j)=1;
                j=j+1;
            elseif Gg(i,j)==GU 
                k(2)=k(2)+1;
                Case(i,j)=2;
                j=j+1;
            elseif dp(i,j)>=0 && dp(i,j)<=2^m-1
                k(3)=k(3)+1;
                Case(i,j)=3;
                j=j+1;
            elseif dp(i,j)<0 && dp(i,j)>=-(2^m-1)
                k(4)=k(4)+1;  
                Case(i,j)=4;
                j=j+1;
            elseif abs(dp(i,j))>2^m-1 && (abs(dp(i,j+1))<=2^m-1 || abs(dp(i,j+2))<=2^m-1)
                k(5)=k(5)+1;
                Case(i,j)=5;
                j=j+1;
             elseif abs(dp(i,j))>2^m-1 && abs(dp(i,j+1))>2^m-1 && abs(dp(i,j+2))>2^m-1
                k(7)=k(7)+1;
                Case(i,j)=7;
                Case(i,j+1)=7;
                Case(i,j+2)=7;
                j=j+3;
            end
        end
    end
    %Li3=sum(k)
    Case(:,end+1) = 0;
    r={[0 0] [0 1] [1 0 0] [1 0 1] [1 1 0] [1 1 1 0] [1 1 1 1]};  %��ԭʼ��r
    [val,ind]=sort(k,'descend');
    rp(ind)=r;                                                     %����Ҫ�������������r
    L1=length(rp{1});L2=length(rp{2});L3=length(rp{3});
    L4=length(rp{4});L5=length(rp{5});L6=length(rp{6});L7=length(rp{7});
    Lindicator =sum(sum(k.*[L1 L2 L3 L4 L5 L6 L7]))
    l2 = sum(sum(k.*[2 2 3 3 3 4 4]))
    Length_Prediction=(k(3)+k(4))*m+k(5)*GN+k(7)*3*GN;
    %fprintf('Lindicator=%d,Length_Prediction=%d\n',Lindicator,Length_Prediction);
    %%  ����
    rng(999)
    S=randi([0 1],[1,sbit*numel(G)]);
    Gcs=[];
    k=1;
    cnt=1;
    % �����һ��Ԫ��
    Gcs(k:k+sbit-1)=S(cnt:cnt+sbit-1);
    k=k+sbit;
    cnt=cnt+sbit;
    Gcs(k:k+GN-1)=D2B(G(1,1),GN);
    k=k+GN;
    LP=0;
    %
    for i=1:size(G,1)
        j=1;
        while j<=size(G,2)
            if i==1 && j==1
                j=j+1;
               continue 
            else
                Gcs(k:k+sbit-1)=S(cnt:cnt+sbit-1);
                k=k+sbit;
                cnt=cnt+sbit;
                if Case(i,j)==1
                    Gcs(k:k+L1-1)=rp{1};
                    k=k+L1;
                    j=j+1;
                elseif Case(i,j)==2
                    Gcs(k:k+L2-1)=rp{2};
                    k=k+L2;
                    j=j+1;
                elseif Case(i,j)==3
                    Gcs(k:k+L3-1)=rp{3};
                    k=k+L3;
                    Gcs(k:k+m-1)=D2B(d(i,j),m);
                    k=k+m;
                    LP=LP+m;
                    j=j+1;
                elseif Case(i,j)==4
                    Gcs(k:k+L4-1)=rp{4};
                    k=k+L4;
                    Gcs(k:k+m-1)=D2B(abs(d(i,j)),m);
                    k=k+m;
                    LP=LP+m;
                    j=j+1;
                elseif Case(i,j)==5
                    Gcs(k:k+L5-1)=rp{5};
                    k=k+L5;
                    Gcs(k:k+GN-1)=D2B(G(i,j),GN);
                    k=k+GN;
                     LP=LP+GN;
                    j=j+1;
                elseif Case(i,j)==6 %����Ӧ�γ̱��룬��������������ͬ�ľͲ�0������λ��1
                    Gcs(k:k+L6-1)=rp{6};
                    k=k+L6;
                    flag = 1;
                    jj = 0;
                    while flag == 1 
                       if Case(i,j+jj+1) == 6
                          jj = jj + 1;
                       else
                           flag = 0;
                       end
                    end
                    if jj > 2
                        for temp = 1:jj -2
                           Gcs(k) = 0;
                           k = k + 1;
                        end
                    end
                    Gcs(k) = 1;
                    k = k + 1;
                    Gcs(k:(k+jj*sbit-1))=S(cnt:(cnt+jj*sbit-1));
                    k=k+jj*sbit;
                    cnt=cnt+jj*sbit;
                    j=j+jj+1;
%                  elseif Case(i,j)==7
%                     Gcs(k:k+L7-1)=rp{7};
%                     k=k+L7;
%                     flag = 1;
%                     jj = 0;
%                     while flag == 1
%                        if Case(i,j+jj+1) == 7
%                           jj = jj + 1;
%                        else
%                            flag = 0;
%                        end
%                     end
%                     if jj > 2
%                         for temp = 1:jj -2
%                            Gcs(k) = 0;
%                            k = k + 1;
%                         end
%                     end
% %                     Gcs(k) = 1;
% %                     k = k + 1;
%                     Gcs(k:(k+jj*sbit-1))=S(cnt:(cnt+jj*sbit-1));
%                     k=k+jj*sbit;
%                     cnt=cnt+jj*sbit;
% %                     Gcs(k:k+GN-1)=D2B(G(i,j),GN);
% %                     k=k+GN;
% %                     LP=LP+GN;
% %                     Gcs(k:k+GN-1)=D2B(G(i,j+1),GN);
% %                     k=k+GN;
% %                     LP=LP+GN;
% %                     Gcs(k:k+GN-1)=D2B(G(i,j+2),GN);
% %                     k=k+GN;
% %                     LP=LP+GN;
%                     for temp = 0:jj
%                         Gcs(k:k+GN-1) = D2B(G(i,j+temp),GN);
%                         k = k + GN;
%                         LP = LP + GN;
%                     end
%                     j=j+jj+1;
                elseif Case(i,j)==7
                    Gcs(k:k+L7-1)=rp{7};
                    k=k+L7;
                    Gcs(k:(k+2*sbit-1))=S(cnt:(cnt+2*sbit-1));
                    k=k+2*sbit;
                    cnt=cnt+2*sbit;
                    Gcs(k:k+GN-1)=D2B(G(i,j),GN);
                    k=k+GN;
                    LP=LP+GN;
                    Gcs(k:k+GN-1)=D2B(G(i,j+1),GN);
                    k=k+GN;
                    LP=LP+GN;
                    Gcs(k:k+GN-1)=D2B(G(i,j+2),GN);
                    k=k+GN;
                    LP=LP+GN;
                    j=j+3;

                end
            end
        end
    end
    pure_bitrate=(length(Gcs)-length(S))/(512*512);
    %fprintf('LP=%d,pure_bitrate=%1.3f',LP,pure_bitrate);
    %length(Gcs)/(512*512)

    %%  ����
    RG=zeros(size(G));                         %��ԭ���������
    RS=[];                                     %��ԭ��Ļ�����Ϣ
    k1=1;
    cnt1=1;
    %�Ƚ����һ��Ԫ��
    RS(cnt1:cnt1+sbit-1)=Gcs(k1:k1+sbit-1);
    k1=k1+sbit;
    cnt1=cnt1+sbit;
    RG(1,1)=B2D(Gcs(k1:k1+GN-1));
    k1=k1+GN;
    %
    RGp=zeros(size(G,1),size(G,2));               
    RCase=zeros(size(G,1),size(G,2));           %��ԭ��������
    for i=1:size(G,1)
        j=1;
        while j<=size(G,2)
            if (i==1 && j==1)
                j=j+1;
                continue;
            end
            if i ==6 && j ==128
               0; 
            end
            if i==1 && j~=1
                GL=RG(i,j-1);GU=GL;GUL=GL;GUR = GL;
            elseif i~=1 && (j==1||j == size(G,2))
                GU=RG(i-1,j);GL=GU;GUL=GU;GUR = GU;
            elseif i>=2 && j>=2
                GL=RG(i,j-1);GU=RG(i-1,j);GUL=RG(i-1,j-1);GUR = RG(i-1,j+1);
            end
            RS(cnt1:cnt1+sbit-1)=Gcs(k1:k1+sbit-1);
            k1=k1+sbit;
            cnt1=cnt1+sbit;
            RGp(i,j)=(sum((w'.*[GL GU GUL GUR])));
            if all(Gcs(k1:k1+L1-1)==rp{1})
                k1=k1+L1;
                RG(i,j)=round(GL);
                RCase(i,j)=1;
                j=j+1;
            elseif all(Gcs(k1:k1+L2-1)==rp{2})
                k1=k1+L2;
                RG(i,j)=round(GU);
                RCase(i,j)=2;
                j=j+1;
            elseif all(Gcs(k1:k1+L3-1)==rp{3})
                k1=k1+L3;
                RG(i,j)=round(RGp(i,j)+B2D(Gcs(k1:k1+m-1)));
                k1=k1+m;
                RCase(i,j)=3;
                j=j+1;
            elseif all(Gcs(k1:k1+L4-1)==rp{4})
                k1=k1+L4;
                RG(i,j)=round(RGp(i,j)-B2D(Gcs(k1:k1+m-1)));
                k1=k1+m;
                RCase(i,j)=4;
                j=j+1;
            elseif all(Gcs(k1:k1+L5-1)==rp{5})
                k1=k1+L5;
                RG(i,j)=round(B2D(Gcs(k1:k1+GN-1)));
                k1=k1+GN;
                RCase(i,j)=5;
                j=j+1;
            elseif all(Gcs(k1:k1+L6-1)==rp{6})
                k1=k1+L6;
                jj = 0;
                flag = 1;
                while flag == 1
                   if Gcs(k1+jj) == 0
                      jj = jj + 1;
                   elseif Gcs(k1+jj) == 1
                      flag = 0;
                      k1 = k1 + jj + 1;
                   end
                end
                RS(cnt1:(cnt1+(2+jj)*sbit-1))=Gcs(k1:(k1+(2+jj)*sbit-1));
                cnt1=cnt1+(2+jj)*sbit;
                k1=k1+(2+jj)*sbit;
                for temp = 0:2+jj
                    RG(i,j+temp) = round(GL);
                    RCase(i,j+temp) = 6;
                end
                j = j + 3 + jj;
            elseif all(Gcs(k1:k1+L7-1)==rp{7})
                k1=k1+L7;
                RS(cnt1:(cnt1+2*sbit-1))=Gcs(k1:(k1+2*sbit-1));
                cnt1=cnt1+2*sbit;
                k1=k1+2*sbit;
                RG(i,j)=round(B2D(Gcs(k1:k1+GN-1)));
                k1=k1+GN;
                RG(i,j+1)=round(B2D(Gcs(k1:k1+GN-1)));
                k1=k1+GN;
                RG(i,j+2)=round(B2D(Gcs(k1:k1+GN-1)));
                k1=k1+GN;
                RCase(i,j)=7;
                RCase(i,j+1)=7;
                RCase(i,j+2)=7;
                j=j+3;
            end
        end
    end
    %% ���黹ԭ�Ƿ���ȷ
    RCase(:,end+1) = 0;
    su1=sum(sum(abs(RCase-Case)));
    %sum(sum(abs(RS-S)))
    su3=sum(sum(abs(RG-G)));
    % length(Gcs)/(512*512)
    fprintf('su1=%d,su3=%d\n',su1,su3);
%     benefit = huffman(Gcs);
    pbr = [pbr;(size(Gcs,2) - size(S,2)) / (512*512)];%����������
    br = [br;size(Gcs,2) / (512*512)];%������
    size(Gcs) / (512*512);
    % G=G+1;
    % RG=RG+1;
    % [II]=VQ_jiema(I,C,G,n);
    % figure;
    % imshow(uint8(II))
    %%
    % k7=0;k6=0;k5=0;k4=0;
    % k3=0;k2=0;k1=0;
    % for i=1:numel(Case)
    %     if Case(i)==7
    %         k7=k7+1;
    %     elseif Case(i)==6
    %         k6=k6+1;
    %     elseif Case(i)==5
    %         k5=k5+1;
    %     elseif Case(i)==4
    %         k4=k4+1;
    %     elseif Case(i)==3
    %         k3=k3+1;
    %     elseif Case(i)==2
    %         k2=k2+1;
    %     elseif Case(i)==1
    %         k1=k1+1;
    %     end
    % end
    %%
    % x=[128 256 512 1024];
    % y=[0.2691 0.3194 0.3926 0.4682];
    % hold on
    % plot(x,y,'-ro')
    %length(Gcs)
end
min_br = min(br);
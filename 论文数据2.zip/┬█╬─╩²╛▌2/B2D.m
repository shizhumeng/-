function num=B2D(binVect)
%binVect=[1 1 0];
num=binVect*(2.^(length(binVect)-1:-1:0))';
%num=sum(binVect.*(2.^(length(binVect)-1:-1:0)));
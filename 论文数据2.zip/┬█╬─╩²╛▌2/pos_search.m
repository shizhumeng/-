% PSO search algorithm for rearranging index talbe and codebook
% 
% % % % % % % % % % % % % % % % % %
% Modified by  Zhijie Wu
% Sep,2019 - Jan,2020
% June,2020-
% % % % % % % % % % % % % % % % % % 
% Copyright (c) 2020, Zhijie Wu
% All rights reserved.
%
clc
clear
I=double(imread('Lena_Gray.tiff'));
%%  �������벾
load('CB256.mat');
%codebook = codebook';
n = 4;                                    % 4 * 4��С��
[CB2,ind]=sort(sum(CB256));               
codebook=CB256(:,ind);
N = 256;
[index_table]=VQ_bianma(codebook,I,n,N);                  %���ú��� VQ_bianma ���������� G
%%  ���㹲�־���
index_table_size = size(index_table);
C = zeros(N,N);
for i = 1:index_table_size(1,1)
    series = index_table(i,:);
    series_size = size(series);
    for j = 1:(series_size(1,2)-1)
        C(series(1,j),series(1,j+1)) = C(series(1,j),series(1,j+1)) + 1;
        C(series(1,j+1),series(1,j)) = C(series(1,j+1),series(1,j)) + 1;
    end
end
for i = 1:index_table_size(1,2)
    series = index_table(:,i);
    series_size = size(series);
    for j = 1:(series_size(1,1)-1)
        C(series(j,1),series(j+1,1)) = C(series(j,1),series(j+1,1)) + 1;
        C(series(j+1,1),series(j,1)) = C(series(j+1,1),series(j,1)) + 1;
    end
end
for i = 1:N
    C(i,i) = 0;
end
%% ���������㷨������
temp = unique(index_table);
temp = temp';
L = size(temp,2);%����Ĺ�ģ
%s0 = load('listR.csv');%��ʼ�⣬����ǰ�ķ����������
 %s0 = temp(randperm(L));
 s0 = load('listR.csv');
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��ɢ����Ⱥ������
 posnum=500;
 fitness00=fit(C,s0,L);
 fitness0=zeros(500,1);
    for j=1:posnum
        s{j,1} = temp(randperm(L));
       fitness0(j) = fit(C,s{j,1},L);
    end  
 [bestfitness0 bestindex0]=max(fitness0);
 
 temp=Y1;
  [row,col]=find(pop0==0);
  col=flipud(col);
  row=flipud(row);
 % t=[row,row]
  for j=1:sizepop
      t=find(row==j);
      temp(:,col(t))=[];
      fitness(j) = fit(C,s{j,1},L);
      temp=Y1;
  end  
  [bestfitness bestindex]=max(fitness);
   % [bestfitness bestindex]=max(fitness);
   %   [bestfitness bestindex]=max(fitness);
  zbest1=pop0(bestindex(1),:);
  
zbest=repmat(zbest1,sizepop,1);
%zbest-pop
%Ⱥ�弫ֵλ��
gbest=pop0;             %���弫ֵλ�� 
fitnessgbest= fitness ; %���弫ֵ��Ӧ��ֵ
fitnesszbest=bestfitness;%Ⱥ�弫ֵ��Ӧ��ֵ
 
vmax=6;
n=15;
maxgen =50;
v=(rand(sizepop,n));
for i=1:maxgen 
    i
    v=v+rand(sizepop,n).*(gbest-pop0)+rand(sizepop,n).*(zbest-pop0);
    v(find(abs(v)>vmax))=vmax;
    s=sigmoid(v);%.*(1-sigmoid(v));
    pop0=rand(sizepop,n)<s;
    [row,col]=find(pop0==0);
    col=flipud(col);
    row=flipud(row);
   % t=[col,row]   
    for j=1:sizepop
          t=find(row==j);
      temp(:,col(t))=[];
        fitness(j)=myDNB(temp);
        temp=Y1;
    end    
    for j=1:sizepop
        if(fitness(j)>fitnessgbest(j))
           gbest(j,:)=pop0(j,:);
           fitnessgbest(j)=fitness(j);
           Good_creditgbest(j)=Good_credit(j);
           Bad_creditgbest(j)=Bad_credit(j);
         end    
         %Ⱥ�弫ֵ����
         if(fitnessgbest(j)>fitnesszbest)
           zbest1= gbest(j,:);
           fitnesszbest=fitnessgbest(j)
           Good_creditzbest=Good_creditgbest(j)
           Bad_creditzbest=Bad_creditgbest(j)
           zbest=repmat(zbest1,sizepop,1);
         end
    end 
    result(i)=fitnesszbest;
     resultgc(i)=Good_creditzbest;
      resultbc(i)= Bad_creditzbest;
  end
end
%tabulist = zeros(N);%���ɱ�
%tabulength = 200;%���ɳ���
%candidateNum = 1000;%��ѡ�����
%candidates = zeros(candidateNum,L);%��ѡ�⼯��
bsf = s0;
bestfitness = fit(C,s0,L);
tic
p = 1;
%stop = 80 * L;
stop = 250;%ֹͣ��������
while p < stop
    if candidateNum > L * (L - 1) / 2
       disp('��ѡ�����������n*(n-1)/2') ;
       break;
    end
    along(p) = fit(C,s0,L);
    i = 1;
    A = zeros(candidateNum,2);
    while i <= candidateNum % 
        M = ceil(L * rand(1,2));
        if M(1) ~= M(2)
           A(i,1) = max(M(1),M(2));
           A(i,2) = min(M(1),M(2));
           if i == 1
               isa = 0;
           else
               for j = 1:i - 1
                   if A(i,1) == A(j,1) && A(i,2) == A(j,2)
                       isa = 1;
                       break;
                   else
                       isa = 0;
                   end
               end
           end
           if ~isa
              i = i+1;
           else
           end
        else
        end
    end
    bestCandidateNum = 200;%�������ٸ���ú�ѡ��
    bestCandidate = zeros(bestCandidateNum,4);%1:��ţ�2����Ӧ�ȣ�3��4����������
    F = zeros(1,candidateNum);
    for i = 1:candidateNum
        candidates(i,:) = s0;
        candidates(i,[A(i,2),A(i,1)]) = s0([A(i,1),A(i,2)]);%����������һ����ѡ��
        F(i) = fit(C,candidates(i,:),L);
        if i <= bestCandidateNum
            bestCandidate(i,2) = F(i);
            bestCandidate(i,1) = i;
            bestCandidate(i,3) = s0(A(i,1));
            bestCandidate(i,4) = s0(A(i,2));
        else
            for j = 1:bestCandidateNum
                if F(i) > bestCandidate(j,2)
                   bestCandidate(j,2) = F(i);
                   bestCandidate(j,1) = i;
                   bestCandidate(j,3) = s0(A(i,1));
                   bestCandidate(j,4) = s0(A(i,2));
                   break;
                end
            end
        end
    end
    %��bestCandidate
    [JL,index] = sort(bestCandidate(:,2));
    sbest = bestCandidate(index,:);
    bestCandidate = sbest;
    if bestCandidate(end,2) > bestfitness
        bestfitness = bestCandidate(end,2);
        s0 = candidates(bestCandidate(end,1),:);
        bsf = s0;
        for m = 1:L
            for n = 1:L
                if tabulist(m,n) ~= 0
                    tabulist(m,n) = tabulist(m,n) - 1;
                end
            end
        end
        tabulist(bestCandidate(end,3),bestCandidate(end,4)) = tabulength;
        tabulist(bestCandidate(end,4),bestCandidate(end,3)) = tabulength;%
    else
        for i = bestCandidateNum:-1:1
            if tabulist(bestCandidate(i,3),bestCandidate(i,4)) == 0
                s0 = candidates(bestCandidate(i,1),:);
                for m = 1:L
                    for n = 1:L
                       if tabulist(m,n) ~= 0
                           tabulist(m,n) = tabulist(m,n) - 1;
                       end
                    end
                end
                tabulist(bestCandidate(i,3),bestCandidate(i,4)) = tabulength;
                tabulist(bestCandidate(i,4),bestCandidate(i,3)) = tabulength;
                break;
            else
                if fit(C,candidates(bestCandidate(i,1),:),L) > bestfitness * 0.9
                   s0 = candidates(bestCandidate(i,1),:);
                   %
                   for m = 1:L
                        for n = 1:L
                            if tabulist(m,n) ~= 0
                                tabulist(m,n) = tabulist(m,n) - 1;
                            end
                        end
                   end
                   tabulist(bestCandidate(i,3),bestCandidate(i,4)) = tabulength;
                   tabulist(bestCandidate(i,4),bestCandidate(i,3)) = tabulength;
                   [bestCandidate(i,3),bestCandidate(i,4)]
                   %
                   break;
                end
            end
        end
    end
    p = p + 1;
    arrbestfitness(p) = 1/bestfitness; 
   % figure(1);
    %plot(2:p,arrbestfitness(1,2:end));
%     figure(2);
%     plot(1:p-1,along);
end
toc;
% csvwrite('50000House2.csv',bsf);%Ϊ�˷�����ԣ����԰����򱣴�����
















